            <div class="footer">
                <ul>
                    <?php wp_list_pages(array('item_spacing' => 'discard', 'title_li' => null, 'depth' => 1)) ?>
                </ul>
            </div>
        </div>

        <?php wp_footer(); ?>
    </body>
</html>
